Freelancer Matching System
Project Overview

The Freelancer Matching System is a full-stack web application designed to help recruiters find suitable freelancers for projects based on skills, experience, budget compatibility, and ratings.

The system provides separate functionality for freelancers and recruiters and uses an automated matching engine to rank freelancers according to project requirements. The project demonstrates practical implementation of DBMS concepts and backend development.

Technologies Used
Backend: Node.js
Framework: Express.js
Programming Language: JavaScript
Database: MySQL
Database Connectivity: MySQL2
Authentication: bcrypt
API: REST API
Environment Configuration: dotenv
Development Environment: Visual Studio Code
Key Features
User registration and login
Role-based users: Freelancer and Recruiter
Secure password hashing using bcrypt
Freelancer profile creation and management
Freelancer skill management
Recruiter profile creation
Project creation and management
Project skill requirements
Automated freelancer matching
Freelancer ranking based on skill match, budget, and rating
Trending skills analysis
Match history tracking
Database views for dashboards
DBMS Concepts Used
Relational Database Design
Primary Keys
Foreign Keys
Normalization
Joins
Stored Procedures
Triggers
Views
Aggregation Functions
Window Functions
Indexing
Matching System

The system uses the stored procedure:

generate_project_matches

The procedure:

Removes previous match results.
Matches freelancers with required project skills.
Calculates compatibility scores.
Considers skill match, budget compatibility, and freelancer rating.
Ranks freelancers using ROW_NUMBER().
Stores the generated results in the match_result table.
Database Trigger

The project uses the:

after_match_insert

trigger to automatically record generated matches in the match history whenever a new match is inserted.

Database Views
trending_skills

Displays the most in-demand skills based on project requirements.

freelancer_dashboard

Provides freelancer information along with aggregated skill details for dashboard and analytical purposes.

API Modules
Authentication
User Registration
User Login
Freelancer
Create Freelancer Profile
Update Freelancer Profile
Add Skills
Fetch Freelancer Details
Recruiter
Create Recruiter Profile
Project
Create Project
Add Required Project Skills
Run Freelancer Matching
Project Flow
User Registration
       ↓
Select Role
       ↓
Freelancer / Recruiter
       ↓
Create Profile
       ↓
Recruiter Creates Project
       ↓
Add Required Skills
       ↓
Run Matching Engine
       ↓
Calculate Compatibility Scores
       ↓
Rank Freelancers
       ↓
Display Matching Results
       ↓
Store Match History
Project Structure
skill-match-project-main/
│
├── README.md
├── package.json
├── package-lock.json
├── server.js
├── db.js
└── .env
Installation and Setup

Install the required Node.js dependencies:

npm install

Configure the MySQL database and update the .env file with the required database credentials.

Example:

DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=your_database
PORT=5000
Running the Project

Start the backend server using:

npm start

The server runs on:

http://localhost:5000

You can verify that the backend is running by opening:

http://localhost:5000/

The application should return:

Backend running
Future Enhancements
JWT-based authentication
AI-based freelancer recommendations
Advanced matching algorithms
Real-time notifications
Admin dashboard
Improved freelancer ranking
Advanced analytics and reporting
Conclusion

The Freelancer Matching System demonstrates the integration of Node.js, Express.js, JavaScript, and MySQL to develop a real-world freelancer recruitment platform. The system combines backend APIs with advanced DBMS concepts such as stored procedures, triggers, views, indexing, and ranking functions to provide efficient freelancer-project matching.
